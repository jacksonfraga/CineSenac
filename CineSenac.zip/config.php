<?php
	$nomeSistema = "Sistema BLA-BLA";
	$nomeEmpresa = "Empresa BLA-BLA";
	$enderecoEmpresa = "Rua que não existe";
	
	date_default_timezone_set('America/Sao_Paulo');
?>
